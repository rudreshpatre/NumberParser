﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberParser
{
    /// <summary>
    /// Messages used across Number Parser.
    /// </summary>
    public static class NumberParserConstants
    {  
        public const string UnknownFileFormatMsg = "Unknow file format specified, parser only accepts TEXT,XML and JSON formats.";
        public const string FileFormatExceptionMsg = "Input string was not in a correct format.";
        public const string FileFormatExceptionValidationMsg = "Please enter comma delimited list of integers as the first parameter.";
        public const string UnhandledExceptionMsg = "Unhandled Exception Occurred.";
    }
}
