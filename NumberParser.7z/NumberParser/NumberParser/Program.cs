﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberParser
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Convert delimited integers from command line to intger array.
                var delimitedListInt = args[0];
                var intArray = (delimitedListInt).Split(',').Select(int.Parse).ToArray();

                // Get file format.
                var fileFormat = args[1];
              
                // Parse Numbers
                var parser = NumberParserFactory.Parse(fileFormat);
                if (parser != null)
                {
                    var sortedArray = parser.Sort(intArray);
                    parser.CreateFile(sortedArray);
                }
                else
                {
                    Console.WriteLine(NumberParserConstants.UnknownFileFormatMsg);
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == NumberParserConstants.FileFormatExceptionMsg)
                {
                    Console.WriteLine(NumberParserConstants.FileFormatExceptionValidationMsg);
                }
                else
                {
                    Console.WriteLine(NumberParserConstants.UnhandledExceptionMsg);
                    Console.WriteLine("Exception:{0}", ex);
                }          
            }
           
        }
    }
}
