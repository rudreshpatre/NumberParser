﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberParser
{
    public static class NumberParserFactory
    {
        public static INumberParser Parse(string fileFormat)
        {
            switch (fileFormat.ToUpper())
            {
                case "XML":
                    return new ParseToXml();
                case "JSON":
                    return new ParseToJson();                    
                case "TEXT":
                    return new ParseToText();
                default:
                    return null;
            }

        }
    }
}
