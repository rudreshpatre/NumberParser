﻿using Newtonsoft.Json;
using System;
using System.Linq;

namespace NumberParser
{
    public class ParseToJson : INumberParser
    {
        public void CreateFile(int[] sortedArray)
        {
            Console.WriteLine("Json Format");            

            var jsonStr = JsonConvert.SerializeObject(sortedArray);
            Console.WriteLine(jsonStr);
        }

        public int[] Sort(int[] arr)
        {
            return arr.OrderByDescending(c => c).ToArray();
        }
    }
}