﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberParser
{
    public interface INumberParser
    {
        int[] Sort(int[] numberArray);
        void CreateFile(int[] sortedArray);
    }
}
