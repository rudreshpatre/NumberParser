﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NumberParser
{
    public class ParseToXml :INumberParser
    {       

        public void CreateFile(int[] sortedArray)
        {
            Console.WriteLine("XML Format");
           
            var sbData = new StringBuilder();
            XmlSerializer serializer = new XmlSerializer(sortedArray.GetType());
            StringWriter swWriter = new StringWriter(sbData);
            serializer.Serialize(swWriter, sortedArray);
            Console.WriteLine(sbData.ToString());
           
        }

        public int[] Sort(int[] arr)
        {
            return arr.OrderByDescending(c => c).ToArray();
        }
    }
}