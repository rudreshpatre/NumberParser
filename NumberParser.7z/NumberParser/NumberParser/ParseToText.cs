﻿using System;
using System.Linq;

namespace NumberParser
{
    public class ParseToText : INumberParser
    {
        public void CreateFile(int[] sortedArray)
        {
            Console.WriteLine("Text Format");           
            Console.WriteLine(string.Join(",",sortedArray));
        }

        public int[] Sort(int[] arr)
        {
            return arr.OrderByDescending(c => c).ToArray();
        }
    }
}